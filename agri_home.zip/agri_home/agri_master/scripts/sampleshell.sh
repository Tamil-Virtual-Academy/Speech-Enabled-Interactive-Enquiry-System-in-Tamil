#!/bin/bash

echo "$1" > testfile.txt
