#!/usr/bin/bash

# cwd=`pwd`
# echo $cwd
echo "Hello" > triggerfile
echo "File Written" >> triggerfile
