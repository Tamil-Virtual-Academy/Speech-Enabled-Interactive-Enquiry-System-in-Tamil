<?php

// passthru('echo $PATH');
// passthru('ch_wave -f 44100 -F 16000 -o test.wav test1.wav');

?>
